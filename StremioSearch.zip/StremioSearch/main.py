import sys
import json
import os
import urllib.request
import urllib.parse
import ssl
import subprocess

# --- CONFIGURATION ---
TMDB_API_KEY = 'ac09bcf3d1952c1e258c0b891c5f6c0f'
CONFIG_FILE = 'config.json'

# --- HELPERS ---
def load_config():
    default = {
        "player": "desktop",
        "show_trending": True,
        "show_recommendations": True,
        "search_by_actor": True,
        "search_by_year": True,
        "search_by_genre": True,
        "filter_by_type": True,
        "enhanced_single_instance": True
    }
    if not os.path.exists(CONFIG_FILE): 
        save_config(default)
        return default
    try:
        with open(CONFIG_FILE, 'r') as f: 
            cfg = json.load(f)
            for key in default:
                if key not in cfg:
                    cfg[key] = default[key]
            return cfg
    except: 
        return default

def save_config(new_config):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(new_config, f, indent=2)

def fetch_json(url):
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, context=ctx, timeout=5) as response:
            return json.loads(response.read().decode())
    except: return {}

def fetch_multiple_pages(base_url, max_results=50):
    all_results = []
    pages_needed = (max_results // 20) + 1
    
    for page in range(1, min(pages_needed + 1, 4)):
        url = f"{base_url}&page={page}" if '?' in base_url else f"{base_url}?page={page}"
        data = fetch_json(url)
        results = data.get('results', [])
        if not results:
            break
        all_results.extend(results)
        if len(all_results) >= max_results:
            break
    
    return {'results': all_results[:max_results]}

def get_player_display_name(player):
    return {"desktop": "Desktop App", "web": "Stremio Web", "enhanced": "Stremio Enhanced"}.get(player, "Desktop App")

def parse_query(keyword):
    """Parse query and extract stackable filters"""
    config = load_config()
    filters = {}
    remaining = keyword.lower()
    original = keyword
    
    # Type filter at start
    if config.get('filter_by_type', True):
        if remaining.startswith('movie '):
            filters['type'] = 'movie'
            original = original[6:]
            remaining = remaining[6:]
        elif remaining.startswith('tv '):
            filters['type'] = 'tv'
            original = original[3:]
            remaining = remaining[3:]
    
    # Extract other filters
    if config.get('search_by_actor', True) and 'actor:' in remaining:
        idx = original.lower().index('actor:')
        end = len(original)
        for nf in [' year:', ' genre:']:
            p = original.lower().find(nf, idx + 6)
            if p != -1 and p < end:
                end = p
        filters['actor'] = original[idx+6:end].strip()
        original = (original[:idx] + original[end:]).strip()
        
    if config.get('search_by_year', True) and 'year:' in remaining:
        idx = original.lower().index('year:')
        end = len(original)
        for nf in [' actor:', ' genre:']:
            p = original.lower().find(nf, idx + 5)
            if p != -1 and p < end:
                end = p
        filters['year'] = original[idx+5:end].strip()
        original = (original[:idx] + original[end:]).strip()
        
    if config.get('search_by_genre', True) and 'genre:' in remaining:
        idx = original.lower().index('genre:')
        end = len(original)
        for nf in [' actor:', ' year:']:
            p = original.lower().find(nf, idx + 6)
            if p != -1 and p < end:
                end = p
        filters['genre'] = original[idx+6:end].strip()
        original = (original[:idx] + original[end:]).strip()
    
    return original.strip(), filters

def apply_filters(base_query, filters):
    """Apply stackable filters using TMDB discover API"""
    search_movie = filters.get('type') != 'tv'
    search_tv = filters.get('type') != 'movie'
    
    all_results = []
    
    if search_movie:
        url = f"https://api.themoviedb.org/3/discover/movie?api_key={TMDB_API_KEY}&sort_by=popularity.desc"
        
        if filters.get('year'):
            try:
                url += f"&primary_release_year={int(filters['year'])}"
            except:
                pass
        
        if filters.get('genre'):
            gdata = fetch_json(f"https://api.themoviedb.org/3/genre/movie/list?api_key={TMDB_API_KEY}")
            for g in gdata.get('genres', []):
                if filters['genre'].lower() in g['name'].lower():
                    url += f"&with_genres={g['id']}"
                    break
        
        if filters.get('actor'):
            adata = fetch_json(f"https://api.themoviedb.org/3/search/person?api_key={TMDB_API_KEY}&query={urllib.parse.quote(filters['actor'])}")
            if adata.get('results'):
                url += f"&with_cast={adata['results'][0]['id']}"
        
        if base_query:
            surl = f"https://api.themoviedb.org/3/search/movie?api_key={TMDB_API_KEY}&query={urllib.parse.quote(base_query)}"
            mdata = fetch_multiple_pages(surl, 25)
        else:
            mdata = fetch_multiple_pages(url, 25)
        
        for item in mdata.get('results', []):
            item['media_type'] = 'movie'
            all_results.append(item)
    
    if search_tv:
        url = f"https://api.themoviedb.org/3/discover/tv?api_key={TMDB_API_KEY}&sort_by=popularity.desc"
        
        if filters.get('year'):
            try:
                url += f"&first_air_date_year={int(filters['year'])}"
            except:
                pass
        
        if filters.get('genre'):
            gdata = fetch_json(f"https://api.themoviedb.org/3/genre/tv/list?api_key={TMDB_API_KEY}")
            for g in gdata.get('genres', []):
                if filters['genre'].lower() in g['name'].lower():
                    url += f"&with_genres={g['id']}"
                    break
        
        if filters.get('actor'):
            adata = fetch_json(f"https://api.themoviedb.org/3/search/person?api_key={TMDB_API_KEY}&query={urllib.parse.quote(filters['actor'])}")
            if adata.get('results'):
                url += f"&with_cast={adata['results'][0]['id']}"
        
        if base_query:
            surl = f"https://api.themoviedb.org/3/search/tv?api_key={TMDB_API_KEY}&query={urllib.parse.quote(base_query)}"
            tdata = fetch_multiple_pages(surl, 25)
        else:
            tdata = fetch_multiple_pages(url, 25)
        
        for item in tdata.get('results', []):
            item['media_type'] = 'tv'
            all_results.append(item)
    
    all_results.sort(key=lambda x: x.get('popularity', 0), reverse=True)
    return {'results': all_results[:50]}

def query(keyword):
    config = load_config()
    
    if not keyword:
        return get_main_menu()
    
    if keyword.lower() == "settings":
        return get_settings_menu()
    
    if keyword.lower() == "filters":
        return get_filters_menu()
    
    if keyword.lower() in ["trending", "popular"]:
        url = f"https://api.themoviedb.org/3/trending/all/week?api_key={TMDB_API_KEY}"
        data = fetch_multiple_pages(url, 50)
        return process_results(data, "Trending", 50, True)
    
    base_query, filters = parse_query(keyword)
    
    if filters:
        data = apply_filters(base_query, filters)
        desc = build_filter_desc(filters, base_query)
        return process_results(data, desc, 50, bool(filters))
    
    safe_keyword = urllib.parse.quote(keyword)
    url = f"https://api.themoviedb.org/3/search/multi?api_key={TMDB_API_KEY}&query={safe_keyword}"
    data = fetch_multiple_pages(url, 50)
    return process_results(data, "Search Results", 50, False)

def build_filter_desc(filters, base=""):
    parts = []
    if filters.get('type'):
        parts.append(f"{filters['type'].title()}s")
    if filters.get('genre'):
        parts.append(filters['genre'].title())
    if filters.get('year'):
        parts.append(filters['year'])
    if filters.get('actor'):
        parts.append(f"with {filters['actor']}")
    if base:
        parts.insert(0, f'"{base}"')
    return " | ".join(parts) if parts else "Results"

def process_results(data, category="Results", limit=50, sort_by_popularity=False):
    results = []
    items = data.get('results', [])
    
    if sort_by_popularity:
        items.sort(key=lambda x: x.get('popularity', 0), reverse=True)

    for item in items[:limit]:
        if item.get('media_type') not in ['movie', 'tv']:
            continue
        
        title = item.get('title') if item['media_type'] == 'movie' else item.get('name')
        date = item.get('release_date') if item['media_type'] == 'movie' else item.get('first_air_date')
        year = date[:4] if date else ""
        rating = item.get('vote_average', 0)
        poster = item.get('poster_path')
        icon = f"https://image.tmdb.org/t/p/w92{poster}" if poster else "icon.png"
        label = "Movie" if item['media_type'] == 'movie' else "Series"
        
        results.append({
            "Title": title,
            "SubTitle": f"{label} | {year} | ⭐ {rating:.1f}",
            "IcoPath": icon,
            "JsonRPCAction": {"method": "resolve_and_open", "parameters": [item.get('id'), item['media_type']]}
        })

    return results if results else [{"Title": f"No results in {category}", "SubTitle": "Try another search", "IcoPath": "icon.png"}]
def get_main_menu():
    config = load_config()
    player_mode = get_player_display_name(config['player'])
    
    menu = []
    score = 10000
    
    # 1. RECOMMENDATIONS at the top
    if config.get('show_recommendations', True):
        menu.append({"Title": "Recommendations", "SubTitle": "Popular content trending today", "IcoPath": "icon.png", "Score": score})
        score -= 100
        trending_url = f"https://api.themoviedb.org/3/trending/all/day?api_key={TMDB_API_KEY}"
        trending_data = fetch_json(trending_url)
        if trending_data.get('results'):
            rec_results = process_results(trending_data, "Recommendations", 5, False)
            for rec in rec_results:
                rec["Score"] = score
                score -= 100
            menu.extend(rec_results)
    
    # 2. TRENDING option
    if config.get('show_trending', True):
        menu.append({
            "Title": "Trending Movies & TV",
            "SubTitle": "See what is popular right now",
            "IcoPath": "icon.png",
            "Score": score,
            "JsonRPCAction": {"method": "Flow.Launcher.ChangeQuery", "parameters": ["st trending", True], "dontHideAfterAction": True}
        })
        score -= 100
    
    # 3. SEARCH FILTERS
    menu.append({
        "Title": "🔍 Advanced Search Filters",
        "SubTitle": "Click to see available search options",
        "IcoPath": "icon.png",
        "Score": score,
        "JsonRPCAction": {"method": "Flow.Launcher.ChangeQuery", "parameters": ["st filters", True], "dontHideAfterAction": True}
    })
    score -= 100
    
    # 4. HOME
    menu.append({
        "Title": "Open Home",
        "SubTitle": f"Launch {player_mode} Home Page",
        "IcoPath": "icon.png",
        "Score": score,
        "JsonRPCAction": {"method": "open_page", "parameters": ["home"]}
    })
    score -= 100
    
    # 5. DISCOVER
    menu.append({
        "Title": "Open Discover",
        "SubTitle": "Browse Catalogs",
        "IcoPath": "icon.png",
        "Score": score,
        "JsonRPCAction": {"method": "open_page", "parameters": ["discover"]}
    })
    score -= 100
    
    # 6. LIBRARY
    menu.append({
        "Title": "Open Library",
        "SubTitle": "Go to your Stremio Library",
        "IcoPath": "icon.png",
        "Score": score,
        "JsonRPCAction": {"method": "open_page", "parameters": ["library"]}
    })
    score -= 100
    
    # 7. ADDONS
    menu.append({
        "Title": "Stremio Addons",
        "SubTitle": "Manage your Stremio Addons",
        "IcoPath": "icon.png",
        "Score": score,
        "JsonRPCAction": {"method": "open_page", "parameters": ["addons"]}
    })
    score -= 100
    
    # 8. APP SETTINGS
    menu.append({
        "Title": "Stremio App Settings",
        "SubTitle": "Configure the Stremio Application itself",
        "IcoPath": "icon.png",
        "Score": score,
        "JsonRPCAction": {"method": "open_page", "parameters": ["settings"]}
    })
    score -= 100
    
    # 9. PLUGIN SETTINGS
    menu.append({
        "Title": "Plugin Settings",
        "SubTitle": f"Configure this plugin (Current: {player_mode})",
        "IcoPath": "icon.png",
        "Score": score,
        "JsonRPCAction": {"method": "Flow.Launcher.ChangeQuery", "parameters": ["st settings", True], "dontHideAfterAction": True}
    })
    
    return menu

def get_settings_menu():
    config = load_config()
    p_state = get_player_display_name(config['player'])
    
    return [
        {"Title": "═══ PLAYER SETTINGS ═══", "SubTitle": "Configure which Stremio client to use", "IcoPath": "icon.png"},
        {"Title": f"▶ Preferred Player: {p_state}", "SubTitle": "Click to cycle: Desktop → Web → Enhanced", "IcoPath": "icon.png", "JsonRPCAction": {"method": "toggle_setting", "parameters": ["player"], "dontHideAfterAction": True}},
        {"Title": "═══ QUICK ACCESS FEATURES ═══", "SubTitle": "Show or hide quick access options in main menu", "IcoPath": "icon.png"},
        {"Title": f"{'✓' if config.get('show_trending', True) else '✗'} Show Trending Movies & TV", "SubTitle": "Popular content right now", "IcoPath": "icon.png", "JsonRPCAction": {"method": "toggle_setting", "parameters": ["show_trending"], "dontHideAfterAction": True}},
        {"Title": "═══ SEARCH FEATURES ═══", "SubTitle": "Enable or disable advanced search filters", "IcoPath": "icon.png"},
        {"Title": f"{'✓' if config.get('show_recommendations', True) else '✗'} Show Recommendations", "SubTitle": "Show 5 trending titles at top of main menu", "IcoPath": "icon.png", "JsonRPCAction": {"method": "toggle_setting", "parameters": ["show_recommendations"], "dontHideAfterAction": True}},
        {"Title": f"{'✓' if config.get('search_by_actor', True) else '✗'} Search by Actor", "SubTitle": "Enable 'st actor:name' search", "IcoPath": "icon.png", "JsonRPCAction": {"method": "toggle_setting", "parameters": ["search_by_actor"], "dontHideAfterAction": True}},
        {"Title": f"{'✓' if config.get('search_by_year', True) else '✗'} Search by Year", "SubTitle": "Enable 'st year:2024' search", "IcoPath": "icon.png", "JsonRPCAction": {"method": "toggle_setting", "parameters": ["search_by_year"], "dontHideAfterAction": True}},
        {"Title": f"{'✓' if config.get('search_by_genre', True) else '✗'} Search by Genre", "SubTitle": "Enable 'st genre:action' search", "IcoPath": "icon.png", "JsonRPCAction": {"method": "toggle_setting", "parameters": ["search_by_genre"], "dontHideAfterAction": True}},
        {"Title": f"{'✓' if config.get('filter_by_type', True) else '✗'} Filter by Movie/TV", "SubTitle": "Enable 'st movie' or 'st tv' filters", "IcoPath": "icon.png", "JsonRPCAction": {"method": "toggle_setting", "parameters": ["filter_by_type"], "dontHideAfterAction": True}},
        {"Title": "═══ STREMIO ENHANCED SETTINGS ═══", "SubTitle": "Options specific to Stremio Enhanced", "IcoPath": "icon.png"},
        {"Title": f"{'✓' if config.get('enhanced_single_instance', True) else '✗'} Auto-Restart Enhanced", "SubTitle": "Close & reopen Enhanced with new content (prevents Desktop app launching)", "IcoPath": "icon.png", "JsonRPCAction": {"method": "toggle_setting", "parameters": ["enhanced_single_instance"], "dontHideAfterAction": True}},
        {"Title": "← Back to Main Menu", "SubTitle": "Return to main options", "IcoPath": "icon.png", "JsonRPCAction": {"method": "Flow.Launcher.ChangeQuery", "parameters": ["st ", True], "dontHideAfterAction": True}}
    ]

def get_filters_menu():
    config = load_config()
    menu = []
    score = 10000
    
    if config.get('filter_by_type', True):
        menu.append({"Title": "═══ FILTER BY TYPE ═══", "SubTitle": "Show only movies or TV shows", "IcoPath": "icon.png", "Score": score})
        score -= 100
        menu.append({"Title": "🎬 Movies Only", "SubTitle": "Use 'movie' before any search (e.g., 'st movie batman')", "IcoPath": "icon.png", "Score": score, "JsonRPCAction": {"method": "Flow.Launcher.ChangeQuery", "parameters": ["st movie ", True], "dontHideAfterAction": True}})
        score -= 100
        menu.append({"Title": "📺 TV Shows Only", "SubTitle": "Use 'tv' before any search (e.g., 'st tv game of thrones')", "IcoPath": "icon.png", "Score": score, "JsonRPCAction": {"method": "Flow.Launcher.ChangeQuery", "parameters": ["st tv ", True], "dontHideAfterAction": True}})
        score -= 100
    
    if config.get('search_by_genre', True):
        genres = [("Action", "action"), ("Comedy", "comedy"), ("Drama", "drama"), ("Horror", "horror"), ("Thriller", "thriller"), ("Romance", "romance"), ("Sci-Fi", "sci-fi"), ("Fantasy", "fantasy"), ("Mystery", "mystery"), ("Crime", "crime")]
        menu.append({"Title": "═══ SEARCH BY GENRE ═══", "SubTitle": "Select a genre to browse", "IcoPath": "icon.png", "Score": score})
        score -= 100
        for display, search in genres:
            menu.append({"Title": f"🎬 {display}", "SubTitle": f"Browse {display} content", "IcoPath": "icon.png", "Score": score, "JsonRPCAction": {"method": "Flow.Launcher.ChangeQuery", "parameters": [f"st genre:{search}", True], "dontHideAfterAction": True}})
            score -= 100
    
    if config.get('search_by_year', True):
        menu.append({"Title": "═══ SEARCH BY YEAR ═══", "SubTitle": "Type a year to search", "IcoPath": "icon.png", "Score": score})
        score -= 100
        import datetime
        for year in range(datetime.datetime.now().year, datetime.datetime.now().year - 10, -1):
            menu.append({"Title": f"📅 {year}", "SubTitle": f"Content from {year}", "IcoPath": "icon.png", "Score": score, "JsonRPCAction": {"method": "Flow.Launcher.ChangeQuery", "parameters": [f"st year:{year}", True], "dontHideAfterAction": True}})
            score -= 100
    
    if config.get('search_by_actor', True):
        menu.append({"Title": "═══ SEARCH BY ACTOR ═══", "SubTitle": "Type an actor's name", "IcoPath": "icon.png", "Score": score})
        score -= 100
        menu.append({"Title": "🎭 Search by Actor Name", "SubTitle": "Type 'st actor:NAME' to search", "IcoPath": "icon.png", "Score": score, "JsonRPCAction": {"method": "Flow.Launcher.ChangeQuery", "parameters": ["st actor:", True], "dontHideAfterAction": True}})
        score -= 100
    
    menu.append({"Title": "← Back to Main Menu", "SubTitle": "Return to main options", "IcoPath": "icon.png", "Score": score, "JsonRPCAction": {"method": "Flow.Launcher.ChangeQuery", "parameters": ["st ", True], "dontHideAfterAction": True}})
    return menu

def toggle_setting(key):
    config = load_config()
    if key == "player":
        cycle = {"desktop": "web", "web": "enhanced", "enhanced": "desktop"}
        config['player'] = cycle.get(config['player'], "desktop")
    else:
        config[key] = not config.get(key, True)
    save_config(config)
    print(json.dumps({"method": "Flow.Launcher.ChangeQuery", "parameters": ["st settings", True]}))

def find_enhanced_executable():
    for path in [
        os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Programs', 'stremio-enhanced', 'Stremio Enhanced.exe'),
        os.path.join(os.environ.get('PROGRAMFILES', ''), 'Stremio Enhanced', 'Stremio Enhanced.exe'),
        os.path.join(os.environ.get('PROGRAMFILES(X86)', ''), 'Stremio Enhanced', 'Stremio Enhanced.exe'),
    ]:
        if os.path.exists(path):
            return path
    return None

def is_enhanced_running():
    try:
        return 'Stremio Enhanced.exe' in subprocess.run(['tasklist'], capture_output=True, text=True).stdout
    except:
        return False

def close_enhanced():
    try:
        subprocess.run(['taskkill', '/F', '/IM', 'Stremio Enhanced.exe'], capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
        import time
        time.sleep(0.5)
    except:
        pass

def open_page(page_name):
    config = load_config()
    player = config['player']
    
    if player == 'web':
        urls = {"home": "https://web.stremio.com/#/", "library": "https://web.stremio.com/#/library", "discover": "https://web.stremio.com/#/discover", "addons": "https://web.stremio.com/#/addons", "settings": "https://web.stremio.com/#/settings"}
        os.startfile(urls.get(page_name, "https://web.stremio.com/#/"))
    elif player == 'enhanced':
        urls = {"home": "https://web.stremio.com/#/", "library": "https://web.stremio.com/#/library", "discover": "https://web.stremio.com/#/discover", "addons": "https://web.stremio.com/#/addons", "settings": "https://web.stremio.com/#/settings"}
        enhanced_exe = find_enhanced_executable()
        url = urls.get(page_name, "https://web.stremio.com/#/")
        if not enhanced_exe:
            os.startfile(url)
            return
        if config.get('enhanced_single_instance', True) and is_enhanced_running():
            close_enhanced()
        try:
            subprocess.Popen([enhanced_exe, url], creationflags=subprocess.CREATE_NO_WINDOW)
        except:
            os.startfile(url)
    else:
        urls = {"home": "stremio://", "library": "stremio:///library", "discover": "stremio:///discover", "addons": "stremio:///addons", "settings": "stremio:///settings"}
        os.startfile(urls.get(page_name, "stremio://"))

def resolve_and_open(tmdb_id, media_type):
    config = load_config()
    player = config['player']
    stremio_type = "series" if media_type == "tv" else "movie"
    
    url = f"https://api.themoviedb.org/3/{media_type}/{tmdb_id}/external_ids?api_key={TMDB_API_KEY}"
    data = fetch_json(url)
    imdb_id = data.get('imdb_id')
    identifier = imdb_id if imdb_id else f"tmdb:{tmdb_id}"
    
    if player == 'web':
        os.startfile(f"https://web.stremio.com/#/detail/{stremio_type}/{identifier}")
    elif player == 'enhanced':
        uri = f"https://web.stremio.com/#/detail/{stremio_type}/{identifier}"
        enhanced_exe = find_enhanced_executable()
        if not enhanced_exe:
            os.startfile(uri)
            return
        if config.get('enhanced_single_instance', True) and is_enhanced_running():
            close_enhanced()
        try:
            subprocess.Popen([enhanced_exe, uri], creationflags=subprocess.CREATE_NO_WINDOW)
        except:
            os.startfile(uri)
    else:
        os.startfile(f"stremio:///detail/{stremio_type}/{identifier}")

if __name__ == "__main__":
    try:
        if len(sys.argv) > 1:
            args = json.loads(sys.argv[1])
            method = args.get('method')
            params = args.get('parameters', [])
            
            if method == 'query':
                print(json.dumps({"result": query(params[0] if params else "")}))
            elif method == 'toggle_setting':
                toggle_setting(params[0])
            elif method == 'open_page':
                open_page(params[0])
            elif method == 'resolve_and_open':
                resolve_and_open(params[0], params[1])
    except:
        print(json.dumps({"result": []}))